package tp3;
import package2048.Jeu2048;

public class Main {

	public static void main(String[] args) {
		//new Fenetre(new Jeu2048(7,7,2048));
		new FenetreMenu();
		
	}

}
